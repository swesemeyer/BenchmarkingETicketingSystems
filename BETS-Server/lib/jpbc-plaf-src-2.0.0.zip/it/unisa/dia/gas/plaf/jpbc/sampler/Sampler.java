package it.unisa.dia.gas.plaf.jpbc.sampler;

/**
 * @author Angelo De Caro (jpbclib@gmail.com)
 */
public interface Sampler<E> {

    E sample();

}
